package grammarAlgorithms;

public interface Algorithm {
	
	public abstract void execute();
	
}
