package grammarTools;

public class Variable extends Token{
	
	public Variable(String value){
		super(value);
	}

}
